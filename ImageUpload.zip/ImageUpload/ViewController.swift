//
//  ViewController.swift
//  ImageUpload
//
//  Created by Abhay  on 14/11/19.
//  Copyright © 2019 Abhay. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var FilePath:String?
    var SignedURL:URL?
    var ImageSize:String?
    var ImageUpload:ImageUploader?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      ImageUpload = ImageUploader(_delegate: self)
        
        
        FilePath = Bundle.main.path(forResource: "jpg", ofType: "jpg")
        let attr = (try? FileManager.default.attributesOfItem(atPath: FilePath!)) as [FileAttributeKey:AnyObject]?
              let filesize = attr?[FileAttributeKey.size]?.int64Value
        
    
        SignedURL = URL(string: "https://storage.googleapis.com/yovo-app/test.jpg?Expires=1574169930&GoogleAccessId=maverick%40chrome-weft-229408.iam.gserviceaccount.com&Signature=RBsAnXwszDgE8MhWzICs6MSzMSHAGdMuldaB4ibg9vP5Aii8mZI4NwKVjXiOoMiTodRV8mr0oG8FZjx0jJ7WycK65OPMqjp3NHAeJWdZo%2B1i4bUWCB5V3lODAPmm7yhUX36uuGgr4vJ90JOdjK9wEzTIHNemqEFqcvev1%2B2MAsgQKvRzKBzzfP5kW%2F%2BdhmyubfOV5BbFi1N4QMUdLbotvKz3KeLx3pI38LXspuSJ7q3AdKhUfN%2BCh2gJOT26OOf%2BNgk8aIk0Bo4EiUTHMc61xY5FkbFLcz%2FXfByUviijnoZHRfSUvPZEu87HSClONfZD7bMBOQbhgyPojes569xVYw%3D%3D")
        
        ImageUpload?.SendRequestToUploadImage(uploadUrl: SignedURL!, Csize: filesize!.description, filepath: FilePath!)
        
        
    }


    
    
    
    
    
}

