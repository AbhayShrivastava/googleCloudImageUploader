//
//  ImageUploader.swift
//  ImageUpload
//
//Created by Abhay  on 14/11/19.
//  Copyright © 2019 Abhay. All rights reserved.


import Foundation



class  ImageUploader:NSObject,URLSessionDelegate,URLSessionDataDelegate,URLSessionTaskDelegate {

    
    weak var delegate:AnyObject?
    var UploadTask:URLSessionUploadTask?
    
    
    init(_delegate: AnyObject) {
           delegate = _delegate
         
       }
    
    //request and upload method as single file
    
    
    func SendRequestToUploadImage(uploadUrl:URL,Csize:String,filepath:String)
    {
        
        let request = NSMutableURLRequest()
        
        request.httpMethod = "PUT"
        request.url = uploadUrl
        request.setValue("image/jpg", forHTTPHeaderField: "Content-Type")
        request.setValue("public-read", forHTTPHeaderField: "x-goog-acl")
        // request.httpBody = NSData(contentsOf:URL(string: filepath)! ) as Data?
     
        let sessionConfig:URLSessionConfiguration=URLSessionConfiguration.default
               
               
               
               let Session:Foundation.URLSession = URLSession(configuration: sessionConfig, delegate:self , delegateQueue: OperationQueue.current)
             
        UploadTask = Session.uploadTask(with: request as URLRequest, fromFile:URL(string:filepath)! , completionHandler:{
                   (data,response,error) in
                   
                   print(response)
                  
               })
        
        
        UploadTask?.resume()
        
        print("Uploading...")
        
        
        
    }
    //for progress bar
           func urlSession(_ session: URLSession, task: URLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
               let progress = Float(totalBytesSent)/Float(totalBytesExpectedToSend)
               
               let progresspercent = Int(progress*100)
               
               print(progresspercent)
               
           }
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {

           if let httpResponse = response as? HTTPURLResponse {
             let  responseStatus = httpResponse.statusCode

               if (responseStatus == 200) {
                   
                   print("ho gya")
               
               } else if (responseStatus >= 400 && responseStatus < 500) {
                   // Client error
                   print("Upload was not accepted");
                   self.UploadTask?.cancel()
               } else if (responseStatus >= 500 && responseStatus < 600) {
                   // Server error
                   print("Upload was not accepted");
                   self.UploadTask?.cancel()
               } else {
                   self.UploadTask?.cancel()
                print("Unexpected status code:", responseStatus);
               }
           }
           completionHandler(Foundation.URLSession.ResponseDisposition.allow)
       }
       
    
    
    
    
    
    
    
    
    
    
}
